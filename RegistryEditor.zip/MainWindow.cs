﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using RegistryEditor.Helper;
using RegistryEditor.Models;

namespace RegistryEditor
{
    public partial class MainWindow : Form
    {
        //private const string RefreshContextMenuItem = "Refresh";
        //private const string NewGroupContextMenuItem = "New Group";
        //private const string MapRegistryContextMenuItem = "Map Registry";
        //private const string RenameContextMenuItem = "Rename";
        //private const string DeleteContextMenuItem = "Delete";

        private const string DatabaseWarningMessage = "You are going to modify Database registry/group registry, would you like to proceed?";
        private const string GroupRegistryAlreadyExistsMessage = "This group registry with name '{0}' already exists, try again with different name.";
        private const string RegistryAlreadyMappedMessage = "Registry '{0}' already mapped to this group.";
        private const string GroupRegistryConfirmationMessage = "Registry group '{0}' will be deleted permanently, would you like to proceed?";
        public MainWindow()
        {
            InitializeComponent();
        }

        //private void AddContextMenu()
        //{
        //    var registryTreeViewActionMenu = new ContextMenuStrip();
        //    registryTreeViewActionMenu.Items.AddRange(new ToolStripItem[] {
        //        new ToolStripMenuItem() { Text = RefreshContextMenuItem }
        //    });
        //    registryTreeViewActionMenu.ItemClicked += registryTreeViewActionMenu_Clicked;
        //    registryTreeView.ContextMenuStrip = registryTreeViewActionMenu;

        //    var registryBatchTreeViewMenu = new ContextMenuStrip();
        //    registryBatchTreeViewMenu.Items.AddRange(new ToolStripMenuItem[]
        //    {
        //        new ToolStripMenuItem() { Text = RefreshContextMenuItem },
        //        new ToolStripMenuItem() { Text = NewGroupContextMenuItem },
        //        new ToolStripMenuItem() { Text = MapRegistryContextMenuItem },
        //        new ToolStripMenuItem() { Text = RenameContextMenuItem },
        //        new ToolStripMenuItem() { Text = DeleteContextMenuItem },
        //    });
        //    registryBatchTreeViewMenu.ItemClicked += registryBatchTreeViewActionMenu_Clicked;
        //    groupRegistryTreeView.ContextMenuStrip = registryBatchTreeViewMenu;
        //}

        //private void registryBatchTreeViewActionMenu_Clicked(object sender, ToolStripItemClickedEventArgs e)
        //{
        //    var clickedContextMenu = e.ClickedItem.AccessibilityObject.Name;
        //    bool configUpdated = false;
        //    switch (clickedContextMenu)
        //    {
        //        case RefreshContextMenuItem:
        //            {
        //                Reload();
        //                break;
        //            }
        //        case NewGroupContextMenuItem:
        //            {
        //                var inputForm = new InputTextForm("Add new group");
        //                inputForm.ShowDialog();
        //                if (!string.IsNullOrEmpty(inputForm.InputText))
        //                {
        //                    if (groupRegistryTreeView.Nodes.AsParallel().Cast<TreeNode>().Any(node =>
        //                            node.Text.Equals(inputForm.InputText, StringComparison.InvariantCultureIgnoreCase)))
        //                    {
        //                        DisplayWarning(string.Format(GroupRegistryAlreadyExistsMessage, inputForm.InputText));
        //                    }
        //                    else
        //                    {
        //                        var newNode = new TreeNode(inputForm.InputText);
        //                        groupRegistryTreeView.Nodes.Add(newNode);
        //                        var newGroup = new RegistryGroup(inputForm.InputText);
        //                        newNode.Tag = newGroup;
        //                        ConfigurationHelper.Configuration.Groups.Add(newGroup);
        //                        configUpdated = true;
        //                    }
        //                }

        //                break;
        //            }
        //        case RenameContextMenuItem:
        //        case DeleteContextMenuItem:
        //        case MapRegistryContextMenuItem:
        //            {
        //                var selectedNode = groupRegistryTreeView.SelectedNode;
        //                if (selectedNode != null)
        //                {
        //                    if (selectedNode.Level == 0)
        //                    {
        //                        var registryGroup = (RegistryGroup)selectedNode.Tag;

        //                        if (!registryGroup.IsReadOnly)
        //                        {
        //                            switch (clickedContextMenu)
        //                            {
        //                                case RenameContextMenuItem:
        //                                    {
        //                                        var inputForm = new InputTextForm("Rename group", registryGroup.Name);
        //                                        inputForm.ShowDialog();
        //                                        if (!string.IsNullOrEmpty(inputForm.InputText))
        //                                        {
        //                                            if (groupRegistryTreeView.Nodes.AsParallel().Cast<TreeNode>().Any(node => node != selectedNode && node.Text.Equals(inputForm.InputText, StringComparison.InvariantCultureIgnoreCase)))
        //                                            {
        //                                                DisplayWarning(string.Format(GroupRegistryAlreadyExistsMessage, inputForm.InputText));
        //                                            }
        //                                            else
        //                                            {
        //                                                registryGroup.Name = selectedNode.Text = inputForm.InputText;
        //                                                configUpdated = true;
        //                                            }
        //                                        }

        //                                        break;
        //                                    }
        //                                case DeleteContextMenuItem:
        //                                    {
        //                                        if (MessageBox.Show(string.Format(GroupRegistryConfirmationMessage, registryGroup.Name), "Delete confirmation",
        //                                                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) ==
        //                                            DialogResult.Yes)

        //                                        {
        //                                            selectedNode.Nodes.Remove(selectedNode);
        //                                            ConfigurationHelper.Configuration.Groups.Remove(registryGroup);
        //                                            configUpdated = true;
        //                                        }

        //                                        break;
        //                                    }
        //                                case MapRegistryContextMenuItem:
        //                                    {
        //                                        var registryPicker = new RegistryPicker(registryTreeView.Nodes);
        //                                        registryPicker.ShowDialog();
        //                                        if (!string.IsNullOrEmpty(registryPicker.SelectedRegistry))
        //                                        {
        //                                            var newKey = GroupRegistryConfiguration.RootKey + "\\" +
        //                                                         registryPicker.SelectedRegistry;
        //                                            if (selectedNode.Nodes.AsParallel().Cast<TreeNode>().Any(node => (node.Tag as RegistryEntry).Path.Equals(newKey, StringComparison.InvariantCultureIgnoreCase)))
        //                                            {
        //                                                DisplayWarning(string.Format(RegistryAlreadyMappedMessage, newKey));
        //                                            }
        //                                            else
        //                                            {
        //                                                var newNode = new TreeNode(newKey);
        //                                                selectedNode.Nodes.Add(newNode);
        //                                                var newRegistry = new RegistryEntry { Path = newKey };
        //                                                newNode.Tag = newRegistry;
        //                                                registryGroup.RegistryValues.Add(newRegistry);
        //                                                configUpdated = true;
        //                                            }

        //                                        }

        //                                        break;
        //                                    }
        //                            }
        //                        }
        //                        else
        //                        {
        //                            DisplayWarning("This group registry is not editable.");
        //                        }
        //                    }
        //                    else
        //                    {
        //                        var registryEntry = (RegistryEntry)selectedNode.Tag;
        //                        var registryGroup = (RegistryGroup)selectedNode.Parent.Tag;
        //                        switch (clickedContextMenu)
        //                        {
        //                            case DeleteContextMenuItem:
        //                                {
        //                                    if (registryGroup.IsReadOnly)
        //                                    {
        //                                        DisplayWarning("Operation not allowed.");
        //                                    }
        //                                    else
        //                                    {
        //                                        registryGroup.RegistryValues.Remove(registryEntry);
        //                                        selectedNode.Parent.Nodes.Remove(selectedNode);
        //                                        configUpdated = true;
        //                                    }
        //                                    break;
        //                                }
        //                            default:
        //                                {
        //                                    DisplayWarning("Operation not allowed.");
        //                                    break;
        //                                }
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    DisplayWarning("Group registry is not selected.");
        //                }
        //                break;
        //            }
        //    }

        //    if (configUpdated)
        //    {
        //        ConfigurationHelper.Save();
        //        Reload();
        //    }
        //}

        public void DisplayWarning(string message)
        {
            MessageBox.Show(message, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //private void registryTreeViewActionMenu_Clicked(object sender, ToolStripItemClickedEventArgs e)
        //{
        //    var clicked = e.ClickedItem.AccessibilityObject.Name;
        //    switch (clicked)
        //    {
        //        case RefreshContextMenuItem:
        //            {
        //                Reload();
        //                break;
        //            }
        //    }
        //}

        private void Initialize()
        {
            this.Text = string.Format("{0}(Root: {1})", this.Text, GroupRegistryConfiguration.RootKey);
            Reload();
            //AddContextMenu();
            SetButtonState();
        }

        private void ReloadGroupRegistry()
        {
            groupRegistryTreeView.Nodes.Clear();
            foreach (var registryGroup in ConfigurationHelper.Configuration.Groups)
            {
                var node = new TreeNode(registryGroup.Name);
                LoadRegistryGroupTree(node, registryGroup);
                node.Checked = node.Nodes.AsParallel().OfType<TreeNode>().Where(n => n.ForeColor != Color.Red).All(n => n.Checked);
                groupRegistryTreeView.Nodes.Add(node);
            }
            groupRegistryTreeView.CollapseAll();
        }

        private void LoadRegistryGroupTree(TreeNode node, RegistryGroup registryGroup)
        {
            node.Tag = registryGroup;
            foreach (var registry in registryGroup.RegistryValues)
            {
                var registryNode = new TreeNode(registry.Path)
                {
                    Tag = registry
                };
                SetNodeState(registryNode, registry.Path);
                node.Nodes.Add(registryNode);
            }
        }

        private void Reload()
        {
            SetLoading(true);
            ReloadRegistryTree();
            ReloadGroupRegistry();
            SetLoading(false);
        }
        private void SetLoading(bool displayLoader)
        {
            if (displayLoader)
            {
                this.Invoke((MethodInvoker)delegate
                {
                    this.Cursor = Cursors.WaitCursor;
                });
            }
            else
            {
                this.Invoke((MethodInvoker)delegate
                {
                    this.Cursor = Cursors.Default;
                });
            }
        }

        private void ReloadRegistryTree()
        {
            registryTreeView.Nodes.Clear();
            LoadRegistryNodes(GroupRegistryConfiguration.RootKey, registryTreeView.Nodes);
            registryTreeView.ExpandAll();
        }

        public void LoadRegistryNodes(string path, TreeNodeCollection nodes)
        {
            foreach (var key in RegistryKeysOperation.GetSubKeys(path))
            {
                var childPath = path + "\\" + key;
                var node = new TreeNode(key)
                {
                    Tag = childPath
                };
                SetNodeState(node, childPath);
                //Enable this to load multilevel registry entries under Log.
                //LoadRegistryNodes(childPath, node.Nodes);
                nodes.Add(node);
            }
        }

        private void SetNodeState(TreeNode node, string childPath)
        {
            var registryState = RegistryKeysOperation.GetValue(childPath);
            switch (registryState)
            {
                case RegistryState.Disabled:
                    {
                        break;
                    }
                case RegistryState.Enabled:
                    {
                        node.Checked = true;
                        break;
                    }
                case RegistryState.None:
                    {
                        node.ForeColor = Color.Red;
                        break;
                    }
            }
        }

        private void groupRegistryTreeView_AfterCheck(object sender, TreeViewEventArgs e)
        {
            lock (this)
            {
                try
                {
                    var checkedNode = e.Node;
                    if (IsCriticalNode(checkedNode) && !ShowDatabaseWarning(DatabaseWarningMessage))
                        return;
                    SetValueForAllNodes(checkedNode, checkedNode.Checked);
                }
                finally
                {
                    SetTreesState(true);
                    Reload();
                }
            }
        }


        private void registryTreeView_AfterCheck(object sender, TreeViewEventArgs e)
        {
            lock (this)
            {
                try
                {
                    var checkedNode = e.Node;
                    if (IsCriticalNode(checkedNode) &&
                        !ShowDatabaseWarning(DatabaseWarningMessage))
                    {
                        return;
                    }

                    SetValueForAllNodes(checkedNode, checkedNode.Checked);
                }
                finally
                {
                    SetTreesState(true);
                    Reload();
                }

            }
        }

        private bool ShowDatabaseWarning(string title)
        {
            var res = MessageBox.Show(title, "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            return res == DialogResult.Yes;
        }

        private bool IsCriticalNode(TreeNode eNode)
        {
            string path = null;
            if (eNode.Tag is string)
                path = eNode.Tag as string;
            else if (eNode.Tag is RegistryEntry)
                path = ((RegistryEntry)eNode.Tag).Path;
            if (!string.IsNullOrWhiteSpace(path) &&
                path.EndsWith("database", StringComparison.InvariantCultureIgnoreCase))
                return true;

            foreach (TreeNode node in eNode.Nodes)
            {
                if (IsCriticalNode(node))
                {
                    return true;
                }
            }

            return false;
        }

        private void SetValueForAllNodes(TreeNode eNode, bool newValue)
        {
            string path = null;
            if (eNode.Tag is string)
                path = eNode.Tag as string;
            else if (eNode.Tag is RegistryEntry)
                path = ((RegistryEntry)eNode.Tag).Path;
            if (!string.IsNullOrEmpty(path))
                RegistryKeysOperation.SetValue(path, newValue);

            foreach (TreeNode node in eNode.Nodes)
            {
                SetValueForAllNodes(node, newValue);
            }
        }


        private void registryTreeView_BeforeCheck(object sender, TreeViewCancelEventArgs e)
        {
            lock (this)
            {
                SetTreesState(false);
            }
        }

        private void groupRegistryTreeView_BeforeCheck(object sender, TreeViewCancelEventArgs e)
        {
            lock (this)
            {
                SetTreesState(false);
            }
        }

        private void SetTreesState(bool value)
        {
            registryTreeView.Enabled = value;
            groupRegistryTreeView.Enabled = value;
        }

        private void MainWindow_Load(object sender, EventArgs e)
        {
            Initialize();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Reload();
        }

        private void btnMapRegistry_Click(object sender, EventArgs e)
        {
            var selectedNode = groupRegistryTreeView.SelectedNode;
            var registryGroup = (RegistryGroup)selectedNode.Tag;
            var registryPicker = new RegistryPicker(registryTreeView.Nodes, registryGroup.RegistryValues.Select(x => x.Path.Substring(x.Path.LastIndexOf('\\') + 1)).ToList());
            registryPicker.ShowDialog();
            if (!string.IsNullOrEmpty(registryPicker.SelectedRegistry))
            {
                var newKey = GroupRegistryConfiguration.RootKey + "\\" +
                             registryPicker.SelectedRegistry;
                if (selectedNode.Nodes.AsParallel().Cast<TreeNode>().Any(node => (node.Tag as RegistryEntry).Path.Equals(newKey, StringComparison.InvariantCultureIgnoreCase)))
                {
                    DisplayWarning(string.Format(RegistryAlreadyMappedMessage, newKey));
                }
                else
                {
                    var newNode = new TreeNode(newKey);
                    selectedNode.Nodes.Add(newNode);
                    var newRegistry = new RegistryEntry { Path = newKey };
                    newNode.Tag = newRegistry;
                    registryGroup.RegistryValues.Add(newRegistry);
                    ConfigurationHelper.Save();
                    Reload();
                }
            }

        }

        private void btnRename_Click(object sender, EventArgs e)
        {
            var selectedNode = groupRegistryTreeView.SelectedNode;
            var registryGroup = (RegistryGroup)selectedNode.Tag;

            var inputForm = new InputTextForm("Rename group", registryGroup.Name);
            inputForm.ShowDialog();
            if (!string.IsNullOrEmpty(inputForm.InputText))
            {
                if (groupRegistryTreeView.Nodes.AsParallel().Cast<TreeNode>().Any(node => node != selectedNode && node.Text.Equals(inputForm.InputText, StringComparison.InvariantCultureIgnoreCase)))
                {
                    DisplayWarning(string.Format(GroupRegistryAlreadyExistsMessage, inputForm.InputText));
                }
                else
                {
                    registryGroup.Name = selectedNode.Text = inputForm.InputText;
                    ConfigurationHelper.Save();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var selectedNode = groupRegistryTreeView.SelectedNode;
            if (selectedNode.Level == 0)
            {
                var registryGroup = (RegistryGroup)selectedNode.Tag;
                selectedNode.Nodes.Remove(selectedNode);
                ConfigurationHelper.Configuration.Groups.Remove(registryGroup);
            }
            else
            {
                var registryEntry = (RegistryEntry)selectedNode.Tag;
                ((RegistryGroup)selectedNode.Parent.Tag).RegistryValues.Remove(registryEntry);
                selectedNode.Parent.Nodes.Remove(selectedNode);
            }
            ConfigurationHelper.Save();
        }

        private void groupRegistryTreeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            SetButtonState();
        }

        private void SetButtonState()
        {
            var selectedNode = groupRegistryTreeView.SelectedNode;
            if (selectedNode != null)
            {
                var isReadonly =
                    ((selectedNode.Level == 0 ? selectedNode.Tag : selectedNode.Parent.Tag) as RegistryGroup)
                    .IsReadOnly;
                if (isReadonly)
                {
                    EnableEditButtons(false);
                }
                else
                {
                    EnableEditButtons(true);
                    if (selectedNode.Level != 0)
                    {
                        btnRename.Enabled = btnMapRegistry.Enabled = false;
                    }
                }
            }
            else
            {
                EnableEditButtons(false);
            }
        }

        public void EnableEditButtons(bool value)
        {
            btnDelete.Enabled = btnMapRegistry.Enabled = btnRename.Enabled = value;
        }

        private void btnNewGroup_Click(object sender, EventArgs e)
        {
            var inputForm = new InputTextForm("Add new group", string.Empty);
            inputForm.ShowDialog();
            if (!string.IsNullOrEmpty(inputForm.InputText))
            {
                if (groupRegistryTreeView.Nodes.AsParallel().Cast<TreeNode>().Any(node =>
                        node.Text.Equals(inputForm.InputText, StringComparison.InvariantCultureIgnoreCase)))
                {
                    DisplayWarning(string.Format(GroupRegistryAlreadyExistsMessage, inputForm.InputText));
                }
                else
                {
                    var newNode = new TreeNode(inputForm.InputText);
                    groupRegistryTreeView.Nodes.Add(newNode);
                    var newGroup = new RegistryGroup(inputForm.InputText, false);
                    newNode.Tag = newGroup;
                    ConfigurationHelper.Configuration.Groups.Add(newGroup);
                    ConfigurationHelper.Save();
                }
            }
        }
    }
}
