﻿namespace RegistryEditor.Models
{
    public class RegistryEntry
    {
        public string Path { get; set; }
    }
}
