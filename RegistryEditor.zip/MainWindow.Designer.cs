﻿
namespace RegistryEditor
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.registryTreeViewLabel = new System.Windows.Forms.Label();
            this.registryBatchTreeViewLabel = new System.Windows.Forms.Label();
            this.btnMapRegistry = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnRename = new System.Windows.Forms.Button();
            this.btnNewGroup = new System.Windows.Forms.Button();
            this.groupRegistryTreeView = new RegistryEditor.CustomTreeView();
            this.registryTreeView = new RegistryEditor.CustomTreeView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.endDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.startDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.btnCollectLog = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // registryTreeViewLabel
            // 
            this.registryTreeViewLabel.AutoSize = true;
            this.registryTreeViewLabel.Location = new System.Drawing.Point(437, 10);
            this.registryTreeViewLabel.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.registryTreeViewLabel.Name = "registryTreeViewLabel";
            this.registryTreeViewLabel.Size = new System.Drawing.Size(101, 13);
            this.registryTreeViewLabel.TabIndex = 3;
            this.registryTreeViewLabel.Text = "Manual Enablement";
            // 
            // registryBatchTreeViewLabel
            // 
            this.registryBatchTreeViewLabel.AutoSize = true;
            this.registryBatchTreeViewLabel.Location = new System.Drawing.Point(16, 10);
            this.registryBatchTreeViewLabel.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.registryBatchTreeViewLabel.Name = "registryBatchTreeViewLabel";
            this.registryBatchTreeViewLabel.Size = new System.Drawing.Size(95, 13);
            this.registryBatchTreeViewLabel.TabIndex = 4;
            this.registryBatchTreeViewLabel.Text = "Group Enablement";
            // 
            // btnMapRegistry
            // 
            this.btnMapRegistry.Location = new System.Drawing.Point(334, 227);
            this.btnMapRegistry.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnMapRegistry.Name = "btnMapRegistry";
            this.btnMapRegistry.Size = new System.Drawing.Size(94, 26);
            this.btnMapRegistry.TabIndex = 5;
            this.btnMapRegistry.Text = "Map Registry";
            this.btnMapRegistry.UseVisualStyleBackColor = true;
            this.btnMapRegistry.Click += new System.EventHandler(this.btnMapRegistry_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(334, 192);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(94, 26);
            this.btnRefresh.TabIndex = 6;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(334, 297);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(94, 26);
            this.btnDelete.TabIndex = 7;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnRename
            // 
            this.btnRename.Location = new System.Drawing.Point(334, 262);
            this.btnRename.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnRename.Name = "btnRename";
            this.btnRename.Size = new System.Drawing.Size(94, 26);
            this.btnRename.TabIndex = 8;
            this.btnRename.Text = "Rename";
            this.btnRename.UseVisualStyleBackColor = true;
            this.btnRename.Click += new System.EventHandler(this.btnRename_Click);
            // 
            // btnNewGroup
            // 
            this.btnNewGroup.Location = new System.Drawing.Point(334, 158);
            this.btnNewGroup.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnNewGroup.Name = "btnNewGroup";
            this.btnNewGroup.Size = new System.Drawing.Size(94, 26);
            this.btnNewGroup.TabIndex = 9;
            this.btnNewGroup.Text = "New Group";
            this.btnNewGroup.UseVisualStyleBackColor = true;
            this.btnNewGroup.Click += new System.EventHandler(this.btnNewGroup_Click);
            // 
            // groupRegistryTreeView
            // 
            this.groupRegistryTreeView.CheckBoxes = true;
            this.groupRegistryTreeView.Location = new System.Drawing.Point(13, 28);
            this.groupRegistryTreeView.Margin = new System.Windows.Forms.Padding(1);
            this.groupRegistryTreeView.Name = "groupRegistryTreeView";
            this.groupRegistryTreeView.Size = new System.Drawing.Size(314, 435);
            this.groupRegistryTreeView.TabIndex = 1;
            this.groupRegistryTreeView.BeforeCheck += new System.Windows.Forms.TreeViewCancelEventHandler(this.groupRegistryTreeView_BeforeCheck);
            this.groupRegistryTreeView.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.groupRegistryTreeView_AfterCheck);
            this.groupRegistryTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.groupRegistryTreeView_AfterSelect);
            // 
            // registryTreeView
            // 
            this.registryTreeView.CheckBoxes = true;
            this.registryTreeView.Location = new System.Drawing.Point(434, 28);
            this.registryTreeView.Margin = new System.Windows.Forms.Padding(1);
            this.registryTreeView.Name = "registryTreeView";
            this.registryTreeView.Size = new System.Drawing.Size(320, 435);
            this.registryTreeView.TabIndex = 0;
            this.registryTreeView.BeforeCheck += new System.Windows.Forms.TreeViewCancelEventHandler(this.registryTreeView_BeforeCheck);
            this.registryTreeView.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.registryTreeView_AfterCheck);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(12, 476);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(742, 134);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "End Date:";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(28, 22);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(58, 13);
            this.lblStartDate.TabIndex = 16;
            this.lblStartDate.Text = "Start Date:";
            // 
            // endDateTimePicker
            // 
            this.endDateTimePicker.Location = new System.Drawing.Point(88, 55);
            this.endDateTimePicker.Name = "endDateTimePicker";
            this.endDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.endDateTimePicker.TabIndex = 15;
            // 
            // startDateTimePicker
            // 
            this.startDateTimePicker.Location = new System.Drawing.Point(88, 19);
            this.startDateTimePicker.Name = "startDateTimePicker";
            this.startDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.startDateTimePicker.TabIndex = 14;
            // 
            // btnCollectLog
            // 
            this.btnCollectLog.Location = new System.Drawing.Point(213, 82);
            this.btnCollectLog.Name = "btnCollectLog";
            this.btnCollectLog.Size = new System.Drawing.Size(75, 23);
            this.btnCollectLog.TabIndex = 18;
            this.btnCollectLog.Text = "Collect";
            this.btnCollectLog.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.startDateTimePicker);
            this.groupBox2.Controls.Add(this.btnCollectLog);
            this.groupBox2.Controls.Add(this.endDateTimePicker);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.lblStartDate);
            this.groupBox2.Location = new System.Drawing.Point(422, 9);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(313, 119);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Logs";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(4, 11);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(311, 114);
            this.groupBox3.TabIndex = 20;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Backup";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Filepath:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(79, 49);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(208, 20);
            this.textBox1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(212, 80);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Backup";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(766, 622);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnNewGroup);
            this.Controls.Add(this.btnRename);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnMapRegistry);
            this.Controls.Add(this.registryBatchTreeViewLabel);
            this.Controls.Add(this.registryTreeViewLabel);
            this.Controls.Add(this.groupRegistryTreeView);
            this.Controls.Add(this.registryTreeView);
            this.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.Name = "MainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registry Editor";
            this.Load += new System.EventHandler(this.MainWindow_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RegistryEditor.CustomTreeView registryTreeView;
        private RegistryEditor.CustomTreeView groupRegistryTreeView;
        private System.Windows.Forms.Label registryTreeViewLabel;
        private System.Windows.Forms.Label registryBatchTreeViewLabel;
        private System.Windows.Forms.Button btnMapRegistry;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnRename;
        private System.Windows.Forms.Button btnNewGroup;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker startDateTimePicker;
        private System.Windows.Forms.Button btnCollectLog;
        private System.Windows.Forms.DateTimePicker endDateTimePicker;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
    }
}

