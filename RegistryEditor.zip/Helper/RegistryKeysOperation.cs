﻿using Microsoft.Win32;

namespace RegistryEditor.Helper
{
    public enum RegistryState
    {
        Enabled,
        Disabled,
        None
    }
    public static class RegistryKeysOperation
    {
        public const string Field = "All";
        public const int Enabled = 1;
        public const int Disabled = 0;

        public static string[] GetSubKeys(string path)
        {
            using (var kr = Registry.LocalMachine.OpenSubKey(path))
            {
                return kr != null ? kr.GetSubKeyNames() : new string[] { };
            }
        }

        public static RegistryState GetValue(string path)
        {
            using (var kr = Registry.LocalMachine.OpenSubKey(path))
            {
                if (kr == null)
                    return RegistryState.None;

                var obj = kr.GetValue(Field);
                if (obj == null)
                {
                    return RegistryState.None;
                }
                else
                {
                    return obj.ToString() == Enabled.ToString() ? RegistryState.Enabled : RegistryState.Disabled;
                }
            }
        }

        public static bool SetValue(string path, bool value)
        {
            using (var key = Registry.LocalMachine.OpenSubKey(path, true))
            {
                if (key == null) return false;
                if (key.GetValue(Field) == null) return false;
                key.SetValue(Field, value ? Enabled : Disabled);
                return true;
            }
        }
    }
}